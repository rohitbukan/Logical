#include <iostream> 
 
using namespace std; 
 
int main() 
{ 
     int large = 0; 
     int a[10]; 
 
     int i=0; 
     while(i<10) 
     { 
          cin >> a[i]; 
 
          if(a[i] >  large) 
          large = a[i]; 
          i++;  
     } 
 
     cout << "Greatest number: " << large; 
 
     return 0; 
} 